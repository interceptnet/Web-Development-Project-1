/*
	Escape Velocity by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/


function billme()
{
var v1= document.order.frenchfriesQty.value;
var v2= document.order.hamburgerQty.value;
var v3= document.order.drinkQty.value;
var v4= document.order.discountRB[0];
var v5= document.order.discountRB[1];
var v6= document.order.discountRB[2];
var v7= document.order.donateCB.checked;	
//These lines define the variables.

v1= parseInt(v1);
v2= parseInt(v2);
v3= parseInt(v3);
//These lines make sure that variables 1, 2, and 3 are numbers.

order.subtotalBox.value= (v1*2)+(v2*3)+(v3*1.50)

if (document.order.discountRB[0].checked) {
document.order.subtotalBox.value= (order.subtotalBox.value)*0.9
}
else if (document.order.discountRB[1].checked) {
document.order.subtotalBox.value= (order.subtotalBox.value)*0.95
}
//These lines assign discount function to the radio buttons.

document.order.taxBox.value= (document.order.subtotalBox.value)*0.07



if (document.order.donateCB.checked) {
order.grandtotalBox.value= +1(order.subtotalBox.value*1.07)
}
else {
order.grandtotalBox.value= (order.subtotalBox.value*1.07)
}
//These lines assign function to the checkbox.


if (document.order.discountRB[0].checked) {
document.order.savingsBox.value= ((v1*2)+(v2*3)+(v3*1.50))*0.1
}
else if (document.order.discountRB[1].checked) {
document.order.savingsBox.value= ((v1*2)+(v2*3)+(v3*1.50))*0.05
} 
else if (document.order.discountRB[2].checked) {
document.order.savingsBox.value= 0
}
//These lines define what should be displayed in the discount box.

}


function burgerImage() {
document.mainpic.src="hamburger.jpg"
}

function friesImage(){
document.mainpic.src="frenchfries.jpg"
}

function drinkImage(){
document.mainpic.src="drink.jpg"
}

function restoreImage() {
document.mainpic.src="restaurant.jpg"
}




(function($) {

	skel
		.breakpoints({
			desktop: '(min-width: 737px)',
			tablet: '(min-width: 737px) and (max-width: 1200px)',
			mobile: '(max-width: 736px)'
		})
		.viewport({
			breakpoints: {
				tablet: {
					width: 1080
				}
			}
		});

	$(function() {

		var	$window = $(window),
			$body = $('body');

		// Disable animations/transitions until the page has loaded.
			$body.addClass('is-loading');

			$window.on('load', function() {
				$body.removeClass('is-loading');
			});

		// Fix: Placeholder polyfill.
			$('form').placeholder();

		// CSS polyfills (IE<9).
			if (skel.vars.IEVersion < 9)
				$(':last-child').addClass('last-child');

		// Prioritize "important" elements on mobile.
			skel.on('+mobile -mobile', function() {
				$.prioritize(
					'.important\\28 mobile\\29',
					skel.breakpoint('mobile').active
				);
			});

		// Dropdowns.
			$('#nav > ul').dropotron({
				mode: 'fade',
				noOpenerFade: true,
				alignment: 'center',
				detach: false
			});

		// Off-Canvas Navigation.

			// Title Bar.
				$(
					'<div id="titleBar">' +
						'<a href="#navPanel" class="toggle"></a>' +
						'<span class="title">' + $('#logo').html() + '</span>' +
					'</div>'
				)
					.appendTo($body);

			// Navigation Panel.
				$(
					'<div id="navPanel">' +
						'<nav>' +
							$('#nav').navList() +
						'</nav>' +
					'</div>'
				)
					.appendTo($body)
					.panel({
						delay: 500,
						hideOnClick: true,
						hideOnSwipe: true,
						resetScroll: true,
						resetForms: true,
						side: 'left',
						target: $body,
						visibleClass: 'navPanel-visible'
					});

			// Fix: Remove navPanel transitions on WP<10 (poor/buggy performance).
				if (skel.vars.os == 'wp' && skel.vars.osVersion < 10)
					$('#titleBar, #navPanel, #page-wrapper')
						.css('transition', 'none');

	});

})(jQuery);